//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by iBrent on 12/13/18.
//  Copyright © 2018 iBrent. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

